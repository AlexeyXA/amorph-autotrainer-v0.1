#!/usr/bin/env python3
"""Reproducible external benchmark on AmazonScience/MASSIVE Russian intent data.

Downloads the public parquet files at a pinned Hub commit. Only the official
`train` partition is passed into AMORPH; the official `test` partition remains
unseen until after the internal selector and acceptance gate have completed.

Install the core package plus benchmark readers first:
  python -m pip install -e '.[test]'
  python -m pip install pandas pyarrow huggingface_hub
For the optional E5 route, also run:
  python -m pip install -e '.[embeddings]'

Run:
  python scripts/benchmark_massive_ru.py --output-dir benchmark_runs/massive_ru
  python scripts/benchmark_massive_ru.py --with-e5 --output-dir benchmark_runs/massive_ru_e5
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DATASET_ID = "AmazonScience/massive"
# Pinned revision containing ru-RU/massive-{train,validation,test}.parquet.
DATASET_REVISION = "c4aa61e89895160619e18a94de72f19b99e72ca2"
DATASET_LICENSE = "CC BY 4.0"
DATASET_CARD = "https://huggingface.co/datasets/AmazonScience/massive"
E5_MODEL_ID = "intfloat/multilingual-e5-small"
E5_MODEL_REVISION = "614241f622f53c4eeff9890bdc4f31cfecc418b3"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def download_parquet(filename: str, cache_dir: Path) -> Path:
    try:
        from huggingface_hub import hf_hub_download
    except ImportError as exc:
        raise RuntimeError("Missing benchmark dependency. Install `huggingface_hub`.") from exc
    path = hf_hub_download(
        repo_id=DATASET_ID,
        repo_type="dataset",
        filename=filename,
        revision=DATASET_REVISION,
        cache_dir=str(cache_dir),
    )
    return Path(path)


def load_frame(path: Path):
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError("Missing benchmark dependency. Install `pandas` and `pyarrow`.") from exc
    return pd.read_parquet(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="benchmark_runs/massive_ru")
    parser.add_argument("--with-e5", action="store_true", help="Also train/evaluate multilingual-e5-small embeddings + logistic regression; downloads model weights.")
    parser.add_argument("--max-runtime-seconds", type=float, default=7200.0)
    parser.add_argument("--expected-queries", type=int, default=1000)
    parser.add_argument("--compute-eur-per-hour", type=float, default=0.0)
    parser.add_argument("--human-hours", type=float, default=0.0)
    parser.add_argument("--human-eur-per-hour", type=float, default=0.0)
    args = parser.parse_args()

    out = Path(args.output_dir).resolve()
    data_dir = out / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = out / "hf_cache"

    train_source = download_parquet("ru-RU/massive-train.parquet", cache_dir)
    test_source = download_parquet("ru-RU/massive-test.parquet", cache_dir)
    train_frame = load_frame(train_source)
    test_frame = load_frame(test_source)

    needed = {"utt", "intent", "worker_id"}
    for label, frame in (("train", train_frame), ("test", test_frame)):
        missing = sorted(needed - set(frame.columns))
        if missing:
            raise RuntimeError(f"MASSIVE {label} file is missing required columns: {missing}")

    def clean(frame):
        frame = frame[["utt", "intent", "worker_id"]].copy()
        for name in ("utt", "intent", "worker_id"):
            frame[name] = frame[name].fillna("").astype(str).str.strip()
        frame = frame[(frame["utt"] != "") & (frame["intent"] != "") & (frame["worker_id"] != "")]
        return frame.reset_index(drop=True)

    train_frame = clean(train_frame)
    test_frame = clean(test_frame)
    if train_frame["intent"].nunique() < 2 or test_frame["intent"].nunique() < 2:
        raise RuntimeError("The downloaded dataset does not contain enough intent classes.")
    missing_in_test = sorted(set(train_frame["intent"]) - set(test_frame["intent"]))
    if missing_in_test:
        raise RuntimeError(f"Official test partition lacks training labels: {missing_in_test}")

    train_csv = data_dir / "massive_ru_train.csv"
    test_csv = data_dir / "massive_ru_official_test.csv"
    train_frame.rename(columns={"utt": "text", "intent": "label", "worker_id": "group_id"})[["text", "label", "group_id"]].to_csv(train_csv, index=False, encoding="utf-8")
    test_frame.rename(columns={"utt": "text", "intent": "label"})[["text", "label"]].to_csv(test_csv, index=False, encoding="utf-8")

    provenance = {
        "dataset_id": DATASET_ID,
        "dataset_revision": DATASET_REVISION,
        "locale": "ru-RU",
        "license": DATASET_LICENSE,
        "dataset_card_url": DATASET_CARD,
        "attribution": "Amazon Science / AmazonScience/MASSIVE; see the dataset card for required citation and attribution.",
        "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_files": {
            "train_parquet": {"path": str(train_source), "sha256": sha256_file(train_source), "rows_after_required-field_filter": len(train_frame)},
            "test_parquet": {"path": str(test_source), "sha256": sha256_file(test_source), "rows_after_required-field_filter": len(test_frame)},
        },
        "prepared_files": {
            "train_csv": {"path": str(train_csv), "sha256": sha256_file(train_csv), "rows": len(train_frame)},
            "official_test_csv": {"path": str(test_csv), "sha256": sha256_file(test_csv), "rows": len(test_frame)},
        },
        "train_label_count": int(train_frame["label"].nunique()),
        "test_label_count": int(test_frame["label"].nunique()),
        "train_group_count_worker_id": int(train_frame["group_id"].nunique()),
        "split_policy": "Official MASSIVE train partition only enters AMORPH. Rows sharing worker_id stay in one internal split. Official MASSIVE test is evaluated only after strategy selection and is never used by the selector or acceptance gate.",
        "limitations": [
            "This is a public benchmark, not proof of production performance on a business-specific distribution.",
            "MASSIVE intent classification is a 60-class voice-assistant task, not retrieval/RAG or generative-model fine-tuning.",
            "AMORPH still makes its internal train/validation/gate/test split within the official train partition, so only its train subset fits the models.",
            "The official test partition may include annotation-worker identities also represented in the official training partition; report worker-disjoint internal metrics separately.",
        ],
    }
    write_json(out / "dataset_provenance.json", provenance)

    # Imports are delayed so data provenance is retained even if AMORPH fails.
    from amorph_autotrainer.cost import CostConfig
    from amorph_autotrainer.metrics import classification_metrics
    from amorph_autotrainer.pipeline import run_training
    from amorph_autotrainer.strategies import E5Candidate
    import joblib
    import numpy as np

    strategies = ["tfidf", "e5"] if args.with_e5 else ["tfidf"]
    cost_config = CostConfig(
        max_runtime_seconds=args.max_runtime_seconds,
        max_candidates=len(strategies),
        expected_queries=args.expected_queries,
        compute_eur_per_hour=args.compute_eur_per_hour,
        human_hours=args.human_hours,
        human_eur_per_hour=args.human_eur_per_hour,
        bootstrap_samples=500,
        min_gate_examples_per_class=5,
        random_seed=42,
    )
    result = run_training(
        csv_path=train_csv,
        output_dir=out / "runs",
        text_column="text",
        label_column="label",
        group_column="group_id",
        strategies=strategies,
        config=cost_config,
        e5_model_id=E5_MODEL_ID,
        e5_model_revision=E5_MODEL_REVISION,
    )

    test_texts = test_frame["utt"].tolist()
    test_labels = np.asarray(test_frame["intent"].tolist())
    run_dir = Path(result["run_dir"])

    tfidf_model_path = run_dir / "candidates" / "tfidf" / "model.joblib"
    tfidf_model = joblib.load(tfidf_model_path)
    tfidf_predictions = tfidf_model.predict(test_texts)
    external_metrics = {
        "tfidf": classification_metrics(test_labels, tfidf_predictions),
    }

    if args.with_e5 and (run_dir / "candidates" / "e5" / "classifier.joblib").is_file():
        e5_dir = run_dir / "candidates" / "e5"
        e5_metadata = json.loads((e5_dir / "strategy.json").read_text(encoding="utf-8"))
        encoder = E5Candidate._load_encoder(
            e5_metadata["model_id"], e5_metadata.get("model_revision", E5_MODEL_REVISION)
        )
        classifier = joblib.load(e5_dir / "classifier.joblib")
        e5_features = E5Candidate._encode(encoder, test_texts)
        external_metrics["e5"] = classification_metrics(test_labels, classifier.predict(e5_features))

    benchmark_result = {
        "project": "AMORPH AutoTrainer",
        "project_version": "0.1.0 P0 verification extension",
        "environment": {"python_version": platform.python_version(), "platform": platform.platform()},
        "dataset_provenance_file": str(out / "dataset_provenance.json"),
        "internal_amorph_run": result,
        "selected_strategy": result["selected_strategy"],
        "external_test_metrics_by_strategy": external_metrics,
        "selected_strategy_official_test_metrics": external_metrics.get(result["selected_strategy"]),
        "conclusion": "Official-test metrics are report-only and are calculated after internal selection. Interpret this as a task-specific classification benchmark; do not infer competitiveness against RAG, LLM fine-tuning, or other task families.",
    }
    write_json(out / "benchmark_result.json", benchmark_result)
    print(json.dumps({
        "output_dir": str(out),
        "train_rows": len(train_frame),
        "official_test_rows": len(test_frame),
        "train_classes": int(train_frame["label"].nunique()),
        "test_classes": int(test_frame["label"].nunique()),
        "selected_strategy": result["selected_strategy"],
        "external_test_metrics_by_strategy": external_metrics,
        "provenance_file": str(out / "dataset_provenance.json"),
        "result_file": str(out / "benchmark_result.json"),
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"BENCHMARK ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
